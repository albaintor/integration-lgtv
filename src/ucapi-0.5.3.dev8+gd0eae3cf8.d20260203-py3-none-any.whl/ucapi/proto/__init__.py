"""Protobuf-generated modules for the Integration API.

The `.proto` sources live in this same directory. Use the maintainer script
`scripts/compile_protos.py` to (re)generate the Python modules and commit the
results to version control. Runtime imports should use the generated modules
(e.g., `from ucapi.proto import ucr_integration_voice_pb2`).
"""
